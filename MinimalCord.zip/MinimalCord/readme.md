**MinimalCord - [BD Download](https://betterdiscord.net/ghdl?id=3037) - [Editor](https://gibbu.me/themegen/minimalcord)**  
Changes Discord enough to give it a fresh feel while also making it darker. Supports both Light and Dark themes.

Server Chat - **DARK**
![Server Chat](https://i.imgur.com/ETbCZ1P.jpg)

Server Chat - **LIGHT**
![Server Chat](https://i.imgur.com/dexI8UV.jpg)
